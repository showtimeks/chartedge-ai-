import { useState, useRef, useCallback } from 'react';
import './App.css';
import Header from './components/Header';
import UploadZone from './components/UploadZone';
import SettingsBar from './components/SettingsBar';
import LoadingOverlay from './components/LoadingOverlay';
import ChartDisplay from './components/ChartDisplay';
import RatingCard from './components/RatingCard';
import TradeSetup from './components/TradeSetup';
import AnalysisPanel from './components/AnalysisPanel';
import Disclaimer from './components/Disclaimer';

const API_BASE = '';

function App() {
  const [imageFile, setImageFile] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);
  const [tradingStyle, setTradingStyle] = useState('daytrading');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState(null);
  const resultsRef = useRef(null);

  const handleImageUpload = useCallback((file) => {
    setImageFile(file);
    setImageUrl(URL.createObjectURL(file));
    setAnalysis(null);
    setError(null);
  }, []);

  const handleAnalyze = useCallback(async () => {
    if (!imageFile) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('chart', imageFile);
      formData.append('tradingStyle', tradingStyle);

      const response = await fetch(`${API_BASE}/api/analyze`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Analysis failed');
      }

      setAnalysis(data.analysis);
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err) {
      setError(err.message || 'Failed to analyze chart. Make sure the backend server is running.');
    } finally {
      setIsAnalyzing(false);
    }
  }, [imageFile, tradingStyle]);

  const handleReset = useCallback(() => {
    setImageFile(null);
    setImageUrl(null);
    setAnalysis(null);
    setError(null);
  }, []);

  return (
    <div className="app">
      <Header />

      <main className="main-content">
        <div className="container">
          {/* Settings Bar */}
          <SettingsBar
            tradingStyle={tradingStyle}
            onStyleChange={setTradingStyle}
          />

          {/* Upload Zone */}
          {!imageUrl && (
            <UploadZone onUpload={handleImageUpload} />
          )}

          {/* Chart + Controls */}
          {imageUrl && (
            <ChartDisplay
              imageUrl={imageUrl}
              analysis={analysis}
              onReset={handleReset}
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
            />
          )}

          {/* Error */}
          {error && (
            <div className="error-banner fade-in">
              <span className="error-icon">⚠</span>
              <span>{error}</span>
              <button className="error-dismiss" onClick={() => setError(null)}>✕</button>
            </div>
          )}

          {/* Loading Overlay */}
          {isAnalyzing && <LoadingOverlay />}

          {/* Results */}
          {analysis && !isAnalyzing && (
            <div className="results-section fade-in" ref={resultsRef}>
              <div className="results-grid">
                {/* Rating Card */}
                <RatingCard analysis={analysis} />
                {/* Trade Setup */}
                <TradeSetup analysis={analysis} tradingStyle={tradingStyle} />
              </div>
              {/* Analysis Panel */}
              <AnalysisPanel analysis={analysis} />
            </div>
          )}

          <Disclaimer />
        </div>
      </main>
    </div>
  );
}

export default App;
