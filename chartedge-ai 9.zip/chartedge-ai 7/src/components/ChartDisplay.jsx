import { useRef, useEffect } from 'react';
import styles from './ChartDisplay.module.css';

function drawLevelLines(canvas, img, analysis) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;

  // Draw chart image
  ctx.clearRect(0, 0, W, H);
  ctx.drawImage(img, 0, 0, W, H);

  if (!analysis) return;

  const { entryPrice, takeProfit, stopLoss, percentageGain, percentageRisk } = analysis;
  if (!entryPrice || !takeProfit || !stopLoss) return;

  // Determine price range to map levels to canvas Y coordinates
  const prices = [entryPrice, takeProfit, stopLoss];
  const minP = Math.min(...prices) * 0.995;
  const maxP = Math.max(...prices) * 1.005;
  const range = maxP - minP;

  const priceToY = (price) => {
    return H - ((price - minP) / range) * H * 0.7 - H * 0.15;
  };

  const drawLine = (price, color, label, sublabel, dashedIfSL = false) => {
    const y = priceToY(price);
    ctx.save();

    // Glow effect
    ctx.shadowColor = color;
    ctx.shadowBlur = 8;

    // Line
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    if (dashedIfSL) {
      ctx.setLineDash([8, 4]);
    }
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;

    // Label background
    const labelX = 8;
    const priceStr = `$${price.toFixed(2)}`;
    ctx.font = '600 12px Inter, sans-serif';
    const labelW = ctx.measureText(label).width + 10;
    const priceW = ctx.measureText(priceStr).width + 10;
    const boxW = Math.max(labelW, priceW) + 12;

    ctx.fillStyle = color;
    ctx.globalAlpha = 0.9;
    roundRect(ctx, labelX, y - 22, boxW, 42, 4);
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.fillStyle = '#fff';
    ctx.font = '700 10px Inter, sans-serif';
    ctx.fillText(label, labelX + 6, y - 8);
    ctx.font = '600 11px JetBrains Mono, monospace';
    ctx.fillText(priceStr, labelX + 6, y + 8);

    // Sublabel on right
    if (sublabel) {
      ctx.font = '600 11px Inter, sans-serif';
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.9;
      const subW = ctx.measureText(sublabel).width + 16;
      roundRect(ctx, W - subW - 8, y - 13, subW, 24, 4);
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#fff';
      ctx.fillText(sublabel, W - subW, y + 4);
    }

    ctx.restore();
  };

  // Fill zone between TP and Entry (green tint)
  const tpY = priceToY(takeProfit);
  const entryY = priceToY(entryPrice);
  const slY = priceToY(stopLoss);

  ctx.save();
  ctx.globalAlpha = 0.06;
  ctx.fillStyle = '#22c55e';
  ctx.fillRect(0, Math.min(tpY, entryY), W, Math.abs(tpY - entryY));
  ctx.globalAlpha = 0.06;
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(0, Math.min(slY, entryY), W, Math.abs(slY - entryY));
  ctx.globalAlpha = 1;
  ctx.restore();

  // Draw lines
  drawLine(takeProfit, '#22c55e', 'TAKE PROFIT', `+${percentageGain?.toFixed(2) || '?'}%`);
  drawLine(entryPrice, '#3b82f6', 'ENTRY', null);
  drawLine(stopLoss, '#ef4444', 'STOP LOSS', `-${percentageRisk?.toFixed(2) || '?'}%`, true);
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export default function ChartDisplay({ imageUrl, analysis, onReset, onAnalyze, isAnalyzing }) {
  const canvasRef = useRef(null);
  const imgRef = useRef(null);

  useEffect(() => {
    if (!imageUrl) return;
    const img = new Image();
    img.src = imageUrl;
    img.onload = () => {
      imgRef.current = img;
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      drawLevelLines(canvas, img, analysis);
    };
  }, [imageUrl, analysis]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'chartedge-analysis.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className={styles.chartDisplay}>
      <div className={styles.toolbar}>
        <div className={styles.toolbarLeft}>
          {analysis && (
            <div className={styles.markupBadge}>
              <span className={styles.markupDot}></span>
              Chart markup active
            </div>
          )}
        </div>
        <div className={styles.toolbarRight}>
          {analysis && (
            <button className={styles.downloadBtn} onClick={handleDownload}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M7 1 L7 9 M4 7 L7 10 L10 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M1 11 L1 13 L13 13 L13 11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              Download
            </button>
          )}
          <button className={styles.resetBtn} onClick={onReset}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2 2 L12 12 M12 2 L2 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
            New Chart
          </button>
        </div>
      </div>

      <div className={styles.canvasWrap}>
        <canvas ref={canvasRef} className={styles.canvas} />
        {!analysis && !isAnalyzing && (
          <div className={styles.canvasOverlay}>
            <p className={styles.overlayText}>Chart loaded — ready to analyze</p>
          </div>
        )}
      </div>

      {!analysis && !isAnalyzing && (
        <div className={styles.analyzeBar}>
          <button className={styles.analyzeBtn} onClick={onAnalyze}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle cx="9" cy="9" r="7" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M6 9 L8 11 L12 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Analyze Chart with AI
          </button>
          <p className={styles.analyzeHint}>Claude Vision will scan patterns, indicators, and levels</p>
        </div>
      )}
    </div>
  );
}
