import { useCallback, useState } from 'react';
import styles from './UploadZone.module.css';

export default function UploadZone({ onUpload }) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useCallback((node) => { if (node) node.value = ''; }, []);

  const handleFile = (file) => {
    if (!file) return;
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      alert('Please upload a PNG or JPG image.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      alert('File size must be under 10MB.');
      return;
    }
    onUpload(file);
  };

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    handleFile(file);
  }, []);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleChange = useCallback((e) => {
    handleFile(e.target.files[0]);
  }, []);

  return (
    <div
      className={`${styles.uploadZone} ${isDragging ? styles.dragging : ''}`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onClick={() => document.getElementById('chart-input').click()}
    >
      <input
        id="chart-input"
        type="file"
        accept="image/png,image/jpeg"
        className={styles.hiddenInput}
        onChange={handleChange}
        ref={inputRef}
      />

      <div className={styles.content}>
        <div className={styles.iconWrap}>
          <div className={styles.iconOuter}>
            <div className={styles.iconInner}>
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                <rect x="4" y="8" width="32" height="24" rx="3" stroke="var(--accent-blue)" strokeWidth="1.5"/>
                <path d="M4 20 L12 14 L20 18 L28 11 L36 16" stroke="#22c55e" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M20 26 L20 32 M16 29 L20 33 L24 29" stroke="var(--accent-blue)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        <div className={styles.textBlock}>
          <h2 className={styles.title}>Upload Chart Image</h2>
          <p className={styles.subtitle}>
            Drop a stock chart screenshot here or click to browse
          </p>
          <div className={styles.formats}>
            <span className={styles.format}>PNG</span>
            <span className={styles.format}>JPG</span>
            <span className={styles.formatSize}>Up to 10MB</span>
          </div>
        </div>

        <div className={styles.hints}>
          <div className={styles.hint}>
            <span className={styles.hintDot} style={{ background: '#22c55e' }}></span>
            <span>Candlestick patterns detected</span>
          </div>
          <div className={styles.hint}>
            <span className={styles.hintDot} style={{ background: '#3b82f6' }}></span>
            <span>Support/resistance identified</span>
          </div>
          <div className={styles.hint}>
            <span className={styles.hintDot} style={{ background: '#a855f7' }}></span>
            <span>RSI/MACD indicators read</span>
          </div>
        </div>

        <button className={styles.uploadBtn} onClick={(e) => { e.stopPropagation(); document.getElementById('chart-input').click(); }}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M8 1 L8 11 M4 5 L8 1 L12 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 12 L2 14 L14 14 L14 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
          Select Chart Image
        </button>
      </div>
    </div>
  );
}
