import styles from './Header.module.css';

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <div className={styles.logo}>
          <div className={styles.logoIcon}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M4 22 L10 14 L16 18 L22 8" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M18 8 L22 8 L22 12" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="10" cy="14" r="2" fill="#22c55e"/>
              <circle cx="16" cy="18" r="2" fill="#ef4444"/>
              <circle cx="22" cy="8" r="2" fill="#3b82f6"/>
            </svg>
          </div>
          <div className={styles.logoText}>
            <span className={styles.logoName}>ChartEdge</span>
            <span className={styles.logoAi}>AI</span>
          </div>
        </div>

        <div className={styles.tagline}>
          Powered by Claude Vision
        </div>

        <div className={styles.statusBadge}>
          <span className={styles.statusDot}></span>
          <span>Live</span>
        </div>
      </div>
    </header>
  );
}
