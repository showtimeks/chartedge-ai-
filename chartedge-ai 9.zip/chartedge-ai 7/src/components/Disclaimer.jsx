import styles from './Disclaimer.module.css';

export default function Disclaimer() {
  return (
    <div className={styles.disclaimer}>
      <div className={styles.icon}>
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <path d="M9 2 L16 15 L2 15 Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
          <path d="M9 8 L9 11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <circle cx="9" cy="13.5" r="0.75" fill="currentColor"/>
        </svg>
      </div>
      <div className={styles.text}>
        <strong>Disclaimer:</strong> This is not financial advice. ChartEdge AI uses artificial intelligence for educational chart analysis only.
        Always do your own research and consult a licensed financial advisor before making investment decisions.{' '}
        <strong>Trade at your own risk.</strong>
      </div>
    </div>
  );
}
