import styles from './SettingsBar.module.css';

const styles_options = [
  {
    id: 'scalping',
    label: 'Scalping',
    desc: 'Minutes to Hours',
    icon: (
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M9 3 L9 9 L13 13" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
        <circle cx="9" cy="9" r="7" stroke="currentColor" strokeWidth="1.8"/>
      </svg>
    )
  },
  {
    id: 'daytrading',
    label: 'Day Trading',
    desc: 'Same Day',
    icon: (
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <circle cx="9" cy="9" r="4" stroke="currentColor" strokeWidth="1.8"/>
        <path d="M9 1 L9 3 M9 15 L9 17 M1 9 L3 9 M15 9 L17 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'swingtrading',
    label: 'Swing Trading',
    desc: 'Days to Weeks',
    icon: (
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M2 14 Q5 4 9 10 Q13 16 16 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none"/>
      </svg>
    )
  }
];

export default function SettingsBar({ tradingStyle, onStyleChange }) {
  return (
    <div className={styles.settingsBar}>
      <div className={styles.label}>Trading Style</div>
      <div className={styles.options}>
        {styles_options.map((opt) => (
          <button
            key={opt.id}
            className={`${styles.option} ${tradingStyle === opt.id ? styles.active : ''}`}
            onClick={() => onStyleChange(opt.id)}
          >
            <span className={styles.optionIcon}>{opt.icon}</span>
            <span className={styles.optionLabel}>{opt.label}</span>
            <span className={styles.optionDesc}>{opt.desc}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
