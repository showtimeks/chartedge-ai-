import styles from './LoadingOverlay.module.css';

const steps = [
  'Scanning candlestick patterns...',
  'Identifying support & resistance...',
  'Reading trend direction...',
  'Analyzing volume signals...',
  'Checking RSI & MACD...',
  'Generating trade setup...',
];

export default function LoadingOverlay() {
  return (
    <div className={styles.overlay}>
      <div className={styles.card}>
        <div className={styles.spinnerWrap}>
          <div className={styles.spinner}>
            <div className={styles.spinnerRing}></div>
            <div className={styles.spinnerCore}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <path d="M4 20 L10 13 L16 16 L22 7" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        <div className={styles.text}>
          <h3 className={styles.title}>Analyzing Your Chart</h3>
          <p className={styles.subtitle}>Claude Vision is scanning your chart</p>
        </div>

        <div className={styles.steps}>
          {steps.map((step, i) => (
            <div key={i} className={styles.step} style={{ animationDelay: `${i * 0.4}s` }}>
              <div className={styles.stepDot}></div>
              <span>{step}</span>
            </div>
          ))}
        </div>

        <div className={styles.progressBar}>
          <div className={styles.progressFill}></div>
        </div>
      </div>
    </div>
  );
}
