import styles from './RatingCard.module.css';

const ratingConfig = {
  'Strong Buy': {
    color: '#22c55e',
    bg: 'rgba(34, 197, 94, 0.1)',
    border: 'rgba(34, 197, 94, 0.3)',
    icon: '🟢',
    circle: '#22c55e',
    label: 'STRONG BUY',
  },
  'Buy': {
    color: '#4ade80',
    bg: 'rgba(74, 222, 128, 0.08)',
    border: 'rgba(74, 222, 128, 0.25)',
    icon: '🟢',
    circle: '#4ade80',
    label: 'BUY',
  },
  'Neutral': {
    color: '#eab308',
    bg: 'rgba(234, 179, 8, 0.08)',
    border: 'rgba(234, 179, 8, 0.25)',
    icon: '🟡',
    circle: '#eab308',
    label: 'NEUTRAL',
  },
  'Sell': {
    color: '#f87171',
    bg: 'rgba(248, 113, 113, 0.08)',
    border: 'rgba(248, 113, 113, 0.25)',
    icon: '🔴',
    circle: '#f87171',
    label: 'SELL',
  },
  'Strong Sell': {
    color: '#ef4444',
    bg: 'rgba(239, 68, 68, 0.1)',
    border: 'rgba(239, 68, 68, 0.3)',
    icon: '🔴',
    circle: '#ef4444',
    label: 'STRONG SELL',
  },
};

function ConfidenceMeter({ value }) {
  const segments = 20;
  const filled = Math.round((value / 100) * segments);
  const color = value >= 70 ? '#22c55e' : value >= 45 ? '#eab308' : '#ef4444';

  return (
    <div className={styles.confidenceWrap}>
      <div className={styles.confidenceLabel}>
        <span>Confidence Score</span>
        <span className={styles.confidenceValue} style={{ color }}>{value}%</span>
      </div>
      <div className={styles.segmentBar}>
        {Array.from({ length: segments }).map((_, i) => (
          <div
            key={i}
            className={styles.segment}
            style={{
              background: i < filled ? color : 'var(--border)',
              opacity: i < filled ? 1 - (i / segments) * 0.3 : 1,
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default function RatingCard({ analysis }) {
  const rating = analysis?.rating || 'Neutral';
  const cfg = ratingConfig[rating] || ratingConfig['Neutral'];

  const trendIcon = {
    'Uptrend': '↗',
    'Downtrend': '↘',
    'Sideways': '→',
  }[analysis?.trendDirection] || '→';

  return (
    <div
      className={styles.card}
      style={{
        background: cfg.bg,
        borderColor: cfg.border,
      }}
    >
      <div className={styles.top}>
        <div className={styles.ratingWrap}>
          <div className={styles.ratingIcon} style={{ color: cfg.color }}>
            {cfg.icon}
          </div>
          <div>
            <div className={styles.ratingLabel} style={{ color: cfg.color }}>
              {cfg.label}
            </div>
            <div className={styles.ratingDesc}>AI Signal Rating</div>
          </div>
        </div>

        <div className={styles.trendBadge}>
          <span className={styles.trendIcon}>{trendIcon}</span>
          <span>{analysis?.trendDirection || 'Sideways'}</span>
        </div>
      </div>

      <ConfidenceMeter value={analysis?.confidence || 50} />

      <div className={styles.metaRow}>
        {analysis?.ticker && (
          <div className={styles.metaItem}>
            <span className={styles.metaLabel}>Ticker</span>
            <span className={styles.metaValue} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {analysis.ticker}
            </span>
          </div>
        )}
        {analysis?.timeframe && (
          <div className={styles.metaItem}>
            <span className={styles.metaLabel}>Timeframe</span>
            <span className={styles.metaValue}>{analysis.timeframe}</span>
          </div>
        )}
        {analysis?.riskRewardRatio && (
          <div className={styles.metaItem}>
            <span className={styles.metaLabel}>R:R Ratio</span>
            <span className={styles.metaValue} style={{ color: '#22c55e' }}>{analysis.riskRewardRatio}</span>
          </div>
        )}
      </div>

      {analysis?.patterns?.length > 0 && (
        <div className={styles.patterns}>
          <div className={styles.patternsLabel}>Detected Patterns</div>
          <div className={styles.patternsList}>
            {analysis.patterns.map((p, i) => (
              <span key={i} className={styles.pattern}>{p}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
