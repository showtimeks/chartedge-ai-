import styles from './AnalysisPanel.module.css';

function Section({ title, icon, children }) {
  return (
    <div className={styles.section}>
      <div className={styles.sectionHeader}>
        <span className={styles.sectionIcon}>{icon}</span>
        <h4 className={styles.sectionTitle}>{title}</h4>
      </div>
      <div className={styles.sectionContent}>{children}</div>
    </div>
  );
}

export default function AnalysisPanel({ analysis }) {
  if (!analysis) return null;

  const { analysis: a, keyLevels, rating } = analysis;
  if (!a) return null;

  const isBullish = rating === 'Strong Buy' || rating === 'Buy';
  const isBearish = rating === 'Strong Sell' || rating === 'Sell';
  const signalColor = isBullish ? '#22c55e' : isBearish ? '#ef4444' : '#eab308';

  return (
    <div className={styles.panel}>
      <div className={styles.panelHeader}>
        <h3 className={styles.panelTitle}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect x="2" y="2" width="14" height="14" rx="2" stroke="var(--accent-blue)" strokeWidth="1.5"/>
            <path d="M5 9 L7.5 11.5 L13 6" stroke="var(--accent-blue)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          AI Analysis Report
        </h3>
        <div className={styles.signalBadge} style={{ color: signalColor, borderColor: signalColor, background: `${signalColor}12` }}>
          {rating}
        </div>
      </div>

      <div className={styles.grid}>
        {/* Trend */}
        <Section title="Trend Analysis" icon="📈">
          <p className={styles.text}>{a.trendExplanation}</p>
        </Section>

        {/* Why this rating */}
        <Section title="Signal Rationale" icon="🎯">
          <p className={styles.text}>{a.reasonForRating}</p>
        </Section>

        {/* Key Levels */}
        <Section title="Key Price Levels" icon="🔑">
          <p className={styles.text}>{a.keyLevelsExplanation}</p>
          {keyLevels && (
            <div className={styles.levelsGrid}>
              <div className={styles.levelGroup}>
                <span className={styles.levelGroupLabel} style={{ color: '#22c55e' }}>Support</span>
                {(keyLevels.support || []).map((p, i) => (
                  <span key={i} className={styles.levelTag} style={{ borderColor: 'rgba(34,197,94,0.3)', color: '#22c55e' }}>
                    ${typeof p === 'number' ? p.toFixed(2) : p}
                  </span>
                ))}
              </div>
              <div className={styles.levelGroup}>
                <span className={styles.levelGroupLabel} style={{ color: '#ef4444' }}>Resistance</span>
                {(keyLevels.resistance || []).map((p, i) => (
                  <span key={i} className={styles.levelTag} style={{ borderColor: 'rgba(239,68,68,0.3)', color: '#ef4444' }}>
                    ${typeof p === 'number' ? p.toFixed(2) : p}
                  </span>
                ))}
              </div>
            </div>
          )}
        </Section>

        {/* Setup Quality */}
        {a.setupQuality && (
          <Section title="Setup Quality" icon="⚡">
            <p className={styles.text}>{a.setupQuality}</p>
          </Section>
        )}
      </div>

      {/* Risk Warnings */}
      {a.riskWarnings?.length > 0 && (
        <div className={styles.warnings}>
          <div className={styles.warningsHeader}>
            <span>⚠</span>
            <span className={styles.warningsTitle}>Risk Warnings</span>
          </div>
          <ul className={styles.warningsList}>
            {a.riskWarnings.map((w, i) => (
              <li key={i} className={styles.warningItem}>
                <span className={styles.warningBullet}>▸</span>
                <span>{w}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
