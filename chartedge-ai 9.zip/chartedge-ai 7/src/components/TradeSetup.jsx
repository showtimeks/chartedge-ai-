import styles from './TradeSetup.module.css';

function PriceRow({ label, price, pct, color, borderColor, icon }) {
  return (
    <div className={styles.priceRow} style={{ borderLeftColor: borderColor }}>
      <div className={styles.priceLeft}>
        <div className={styles.priceIndicator} style={{ background: color }}></div>
        <div>
          <div className={styles.priceLabel}>{label}</div>
          <div className={styles.priceIcon}>{icon}</div>
        </div>
      </div>
      <div className={styles.priceRight}>
        <div className={styles.priceValue} style={{ color, fontFamily: 'JetBrains Mono, monospace' }}>
          ${typeof price === 'number' ? price.toFixed(2) : price}
        </div>
        {pct !== null && (
          <div className={styles.pricePct} style={{ color }}>
            {pct > 0 ? '+' : ''}{typeof pct === 'number' ? pct.toFixed(2) : pct}%
          </div>
        )}
      </div>
    </div>
  );
}

export default function TradeSetup({ analysis, tradingStyle }) {
  if (!analysis) return null;

  const { entryPrice, takeProfit, stopLoss, percentageGain, percentageRisk, riskRewardRatio, indicators } = analysis;

  const styleLabels = {
    scalping: 'Scalping',
    daytrading: 'Day Trading',
    swingtrading: 'Swing Trading',
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div className={styles.headerLeft}>
          <h3 className={styles.title}>Trade Setup</h3>
          <span className={styles.styleTag}>{styleLabels[tradingStyle] || 'Day Trading'}</span>
        </div>
        <div className={styles.rrBadge}>
          <span className={styles.rrLabel}>R:R</span>
          <span className={styles.rrValue}>{riskRewardRatio || '?'}</span>
        </div>
      </div>

      <div className={styles.levels}>
        <PriceRow
          label="Take Profit"
          price={takeProfit}
          pct={percentageGain}
          color="#22c55e"
          borderColor="#22c55e"
          icon="▲ Target"
        />
        <PriceRow
          label="Entry Price"
          price={entryPrice}
          pct={null}
          color="#3b82f6"
          borderColor="#3b82f6"
          icon="● Entry"
        />
        <PriceRow
          label="Stop Loss"
          price={stopLoss}
          pct={percentageRisk ? -percentageRisk : null}
          color="#ef4444"
          borderColor="#ef4444"
          icon="▼ Risk"
        />
      </div>

      {/* Visual Range Bar */}
      <div className={styles.rangeSection}>
        <div className={styles.rangeLabel}>Price Zone Visual</div>
        <div className={styles.rangeBar}>
          <div className={styles.rangeGreen} style={{ flex: percentageGain || 2 }}></div>
          <div className={styles.rangeEntry}></div>
          <div className={styles.rangeRed} style={{ flex: percentageRisk || 1 }}></div>
        </div>
        <div className={styles.rangeFooter}>
          <span style={{ color: '#ef4444' }}>SL ${stopLoss?.toFixed(2)}</span>
          <span style={{ color: '#3b82f6' }}>Entry ${entryPrice?.toFixed(2)}</span>
          <span style={{ color: '#22c55e' }}>TP ${takeProfit?.toFixed(2)}</span>
        </div>
      </div>

      {/* Indicators */}
      {indicators && (
        <div className={styles.indicators}>
          <div className={styles.indicatorsLabel}>Indicator Readings</div>
          <div className={styles.indicatorList}>
            {indicators.rsi && (
              <div className={styles.indicator}>
                <span className={styles.indTag}>RSI</span>
                <span className={styles.indText}>{indicators.rsi}</span>
              </div>
            )}
            {indicators.macd && (
              <div className={styles.indicator}>
                <span className={styles.indTag}>MACD</span>
                <span className={styles.indText}>{indicators.macd}</span>
              </div>
            )}
            {indicators.volume && (
              <div className={styles.indicator}>
                <span className={styles.indTag}>VOL</span>
                <span className={styles.indText}>{indicators.volume}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
